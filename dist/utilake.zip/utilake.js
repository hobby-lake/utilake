(() => {
  // src/utils/logger.ts
  function logger(content) {
    let out_content = `[UTILAKE] ${content}`;
    console.log(out_content);
  }

  // src/actions/shape/cylinder.ts
  var M_DCYLINDER = new Action("make_dot_cylinder", {
    name: "\u30C9\u30C3\u30C8\u5186\u3092\u914D\u7F6E",
    icon: "fa-star",
    click() {
      logger(`${this.name} was used`);
      Blockbench.textPrompt(
        "\u30D1\u30E9\u30E1\u30FC\u30BF",
        "\u8A2D\u7F6E\u5E73\u9762:XY/\u30BB\u30B0\u30E1\u30F3\u30C8:16/\u5185\u5F84:1/\u5916\u5F84:2",
        set_cube_like_sphere
      );
    }
  });
  function set_cube_like_sphere(text) {
    const raw_parameters = text.split("/");
    let axis_plane = 0 /* XY */;
    let segment = 16;
    let size_infrate = 0;
    let inner_diameter = 1;
    let outer_diameter = 2;
    if (text.includes("\u8A2D\u7F6E\u5E73\u9762:") == false || text.includes("\u30BB\u30B0\u30E1\u30F3\u30C8:") == false || text.includes("\u5185\u5F84:") == false || text.includes("\u5916\u5F84:") == false) {
      Blockbench.showQuickMessage("\u7121\u52B9\u306A\u5165\u529B\u3067\u3059\u3002[:]\u306E\u6B21\u306F\u534A\u89D2\u6570\u5B57\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044", 5);
      logger("[ERROR] Unsupported input");
      return;
    }
    raw_parameters.forEach((parameter) => {
      if (parameter.includes("\u8A2D\u7F6E\u5E73\u9762:")) {
        switch (parameter.replace("\u8A2D\u7F6E\u5E73\u9762:", "")) {
          case "XZ":
          case "ZX":
            axis_plane = 1 /* XZ */;
            break;
          case "YZ":
          case "ZY":
            axis_plane = 2 /* YZ */;
            break;
          default:
            axis_plane = 0 /* XY */;
            break;
        }
        logger(`${axis_plane}`);
      } else if (parameter.includes("\u30BB\u30B0\u30E1\u30F3\u30C8:")) {
        segment = Number(parameter.replace(/[^0-9.-]/g, ""));
        logger(`${segment}`);
      } else if (parameter.includes("\u5185\u5F84:")) {
        inner_diameter = Number(parameter.replace(/[^0-9.-]/g, ""));
        logger(`${inner_diameter}`);
      } else if (parameter.includes("\u5916\u5F84:")) {
        outer_diameter = Number(parameter.replace(/[^0-9.-]/g, ""));
        logger(`${outer_diameter}`);
      }
    });
    if (outer_diameter < inner_diameter) {
      Blockbench.showQuickMessage("\u5916\u5F84\u306F\u5185\u5F84\u3088\u308A\u3082\u5927\u304D\u304F\u3057\u3066\u304F\u3060\u3055\u3044", 5);
      logger("[ERROR] Outer diameter must bigger than Inner one");
      return;
    }
    logger(`Segment: ${segment}`);
    logger(`Inner diameter: ${inner_diameter}`);
    logger(`Outer diameter: ${outer_diameter}`);
    let cube_group = [];
    let outer_tangent_coordinates = [];
    for (let seg = 0; seg < segment; seg++) {
      try {
        let deg_theta = 360 / segment * seg;
        let rad_theta = Math.degToRad(deg_theta);
        outer_tangent_coordinates.push([Math.cos(rad_theta) * outer_diameter, Math.sin(rad_theta) * outer_diameter, 0]);
        logger(`[CALC] OuterTangent - ${seg + 1} :${outer_tangent_coordinates[seg]}`);
      } catch (error) {
        logger(`[ERROR] at seg-${seg + 1}`);
      }
    }
    let cube_width = 2 * outer_diameter * Math.sin(Math.degToRad(180 / segment));
    let cube_height = (outer_diameter - inner_diameter) * Math.cos(Math.degToRad(180 / segment));
    Undo.initEdit({ elements: [] });
    let cube_index = 0;
    outer_tangent_coordinates.forEach((coordinate) => {
      let raw_from = [coordinate[0] - cube_width / 2, coordinate[1] + cube_height / 2, 0];
      let raw_to = [coordinate[0] + cube_width / 2, coordinate[1] - cube_height / 2, 0];
      let from;
      let to;
      let angle = [0, 0, 0];
      switch (axis_plane) {
        case 0 /* XY */:
          from = raw_from;
          to = raw_to;
        case 1 /* XZ */:
          from = [raw_from[0], raw_from[2], raw_from[1]];
          to = [raw_to[0], raw_to[2], raw_to[1]];
        case 2 /* YZ */:
          from = [raw_from[2], raw_from[0], raw_from[1]];
          to = [raw_to[2], raw_to[0], raw_to[1]];
      }
      cube_group.push(
        new Cube({
          name: `seg_${cube_index + 1}`,
          from,
          to,
          rotation: angle,
          inflate: size_infrate,
          color: 0,
          origin: [0, 0, 0],
          box_uv: false,
          visibility: true
        }).init()
      );
      logger(`[GEN] c_seg_${cube_index + 1} -> ${coordinate}`);
      cube_index++;
    });
    Undo.finishEdit("make_dot_cylinder", { elements: cube_group });
  }

  // src/actions/shape/polished_cylinder.ts
  var M_CYLINDER = new Action("make_cylinder", {
    name: "\u5186\u3092\u914D\u7F6E",
    icon: "fa-star",
    click() {
      logger(`${this.name} was used`);
      Blockbench.textPrompt(
        "\u30D1\u30E9\u30E1\u30FC\u30BF",
        "\u8A2D\u7F6E\u5E73\u9762:XY/\u30BB\u30B0\u30E1\u30F3\u30C8:16/\u5185\u5F84:1/\u5916\u5F84:2",
        set_cube_like_sphere2
      );
    }
  });
  function set_cube_like_sphere2(text) {
    const raw_parameters = text.split("/");
    let axis_plane;
    let segment = 16;
    let size_infrate = 1;
    let inner_diameter = 1;
    let outer_diameter = 2;
    if (text.includes("\u8A2D\u7F6E\u5E73\u9762:") == false || text.includes("\u30BB\u30B0\u30E1\u30F3\u30C8:") == false || text.includes("\u5185\u5F84:") == false || text.includes("\u5916\u5F84:") == false) {
      Blockbench.showQuickMessage("\u7121\u52B9\u306A\u5165\u529B\u3067\u3059\u3002[:]\u306E\u6B21\u306F\u534A\u89D2\u6570\u5B57\u3092\u5165\u529B\u3057\u3066\u304F\u3060\u3055\u3044", 5);
      logger("[ERROR] Unsupported input");
      return;
    }
    raw_parameters.forEach((parameter) => {
      if (parameter.includes("\u8A2D\u7F6E\u5E73\u9762:")) {
        switch (parameter.replace("\u8A2D\u7F6E\u5E73\u9762:", "")) {
          case "XZ":
          case "ZX":
            axis_plane = 1 /* XZ */;
            break;
          case "YZ":
          case "ZY":
            axis_plane = 2 /* YZ */;
            break;
          default:
            axis_plane = 0 /* XY */;
            break;
        }
        logger(`${axis_plane}`);
      } else if (parameter.includes("\u30BB\u30B0\u30E1\u30F3\u30C8:")) {
        segment = Number(parameter.replace(/[^0-9.-]/g, ""));
        logger(`${segment}`);
      } else if (parameter.includes("\u5185\u5F84:")) {
        inner_diameter = Number(parameter.replace(/[^0-9.-]/g, ""));
        logger(`${inner_diameter}`);
      } else if (parameter.includes("\u5916\u5F84:")) {
        outer_diameter = Number(parameter.replace(/[^0-9.-]/g, ""));
        logger(`${outer_diameter}`);
      }
    });
    if (outer_diameter < inner_diameter) {
      Blockbench.showQuickMessage("\u5916\u5F84\u306F\u5185\u5F84\u3088\u308A\u3082\u5927\u304D\u304F\u3057\u3066\u304F\u3060\u3055\u3044", 5);
      logger("[ERROR] Outer diameter must bigger than Inner one");
      return;
    }
    logger(`Segment: ${segment}`);
    logger(`Inner diameter: ${inner_diameter}`);
    logger(`Outer diameter: ${outer_diameter}`);
    let cube_group = [];
    let cube_width = 2 * outer_diameter * Math.sin(Math.degToRad(180 / segment));
    let cube_height = (outer_diameter - inner_diameter) * Math.cos(Math.degToRad(180 / segment));
    let master_vertice = [0, inner_diameter + (outer_diameter - inner_diameter) / 2, 0];
    let master_from = [master_vertice[0] - cube_width / 2, master_vertice[1] + cube_height / 2, 0];
    let master_to = [master_vertice[0] + cube_width / 2, master_vertice[1] - cube_height / 2, 0];
    Undo.initEdit({ elements: [] });
    for (let cube_index = 0; cube_index < segment; cube_index++) {
      let from;
      let to;
      let angle = [0, 0, 0];
      switch (axis_plane) {
        case 0 /* XY */:
          from = master_from;
          to = master_from;
          angle = [360 / segment * cube_index, 0, 0];
          break;
        case 1 /* XZ */:
          from = [master_from[0], master_from[2], master_from[1]];
          to = [master_to[0], master_to[2], master_to[1]];
          angle = [0, 0, 360 / segment * cube_index];
          break;
        case 2 /* YZ */:
          from = [master_from[2], master_from[0], master_from[1]];
          to = [master_to[2], master_to[0], master_to[1]];
          angle = [0, 360 / segment * cube_index, 0];
          break;
      }
      cube_group.push(
        new Cube({
          name: `seg_${cube_index + 1}`,
          //@ts-ignore
          from,
          //@ts-ignore
          to,
          rotation: angle,
          inflate: size_infrate,
          color: 0,
          origin: [0, 0, 0],
          box_uv: false,
          visibility: true
        }).init()
      );
      logger(`[GEN] c_seg_${cube_index + 1}`);
    }
    ;
    Undo.finishEdit("make_cylinder", { elements: cube_group });
  }

  // src/setup_actions.ts
  function setupBarItems() {
    let make_dot_cylinder = M_DCYLINDER;
    let make_cylinder = M_CYLINDER;
    const actions = [];
    let test_action = new Action("my_test_action", {
      name: "[TEST] Say hello to blockbench",
      icon: "help",
      click() {
        logger(`[ACT] ${this.name}`);
        Blockbench.showQuickMessage("Hello Blockbench!");
      }
    });
    actions.push(test_action, make_dot_cylinder, make_cylinder);
    return actions;
  }

  // src/plugin.ts
  var deletables = [];
  BBPlugin.register("utilake", {
    title: "Utilake",
    author: "Lake_A",
    icon: "icon.png",
    version: "0.0.1",
    description: "Tool for JP User",
    variant: "both",
    min_version: "4.10.0",
    has_changelog: false,
    onload() {
      let bar_items = setupBarItems();
      for (let action of bar_items) {
        try {
          deletables.push(action);
          logger(`loading: ${action.name}`);
        } catch (error) {
          logger(`[ERROR] ${error}`);
        }
      }
      logger("Loaded");
    },
    onunload() {
      for (let deletable of deletables) {
        try {
          deletable.delete();
          logger(`unloading: ${deletable.name}`);
        } catch (error) {
          logger(`[ERROR] ${error}`);
        }
      }
      deletables.empty();
      logger("Unloaded");
    }
  });
})();
